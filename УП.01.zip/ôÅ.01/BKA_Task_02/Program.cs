﻿using System;

namespace BKA_Task_02
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exitcheck = false; //для выхода из цикла

            Console.WriteLine("Программа завершится, когда будет введено слово 'exit'");

            while (exitcheck == false)
            {
                var word = Console.ReadLine(); //введенное слово/число
                switch (word)
                {
                    case "exit":
                        exitcheck = true;
                        break;

                    default:
                        Console.WriteLine("Ожидание команды 'exit'");
                        break;
                }
            }
        }
    }
}
