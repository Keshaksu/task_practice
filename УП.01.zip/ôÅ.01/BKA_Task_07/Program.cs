﻿using System;
using System.Linq;

namespace BKA_Task_07
{
    class Program
    {
        static void Main(string[] args)
        {
            int num;
            int i;

            Console.Write("Введите количество элементов массива: ");
            num = Convert.ToInt32(Console.ReadLine());
            double[] array = new double[num];
            Random rand = new Random();
            for(i = 0; i < num; i++)
            {
                array[i] = rand.Next(-200,200);
            }
            Console.WriteLine("\nПервоначальный массив: {0}", string.Join(" ", array));
            Shuffle(array);
            Console.WriteLine("\nКонечный массив: {0}", string.Join(" ", array));
            Console.ReadKey();
        }
        public static void Shuffle(double[] array)
        {
            int i;

            Random random = new Random();
            for (i = 0; i < 7; i++)
            {
                var firstIndex = random.Next(0, array.Count());
                var secondIndex = random.Next(0, array.Count());
                var index = array[firstIndex];
                array[firstIndex] = array[secondIndex];
                array[secondIndex] = index;
            }
        }
    }
}
