﻿using System;

namespace BKA_Task_06
{
    class Program
    {
        static void Main()
        {
            bool exitb = false; //для выхода

            while (exitb == false)
            {
                Console.Write("Отдел кадров\n" +
                "1) добавить досье\n" +
                "2) вывести все досье\n" +
                "3) удалить досье \n" +
                "4) поиск по фамилии \n" +
                "5) выход из программы\n" +
                "\nВыберете пункт меню: ");
                string menuIndex = Console.ReadLine(); //для сравнения и выбора

                switch (menuIndex)
                {
                    case "1":
                        Console.WriteLine(Person.AddPerson());
                        Person.BreakMenu();
                        break;
                    case "2":
                        Console.WriteLine(Person.AllPerson());
                        Person.BreakMenu();
                        break;
                    case "3":
                        Console.WriteLine(Person.DeletePerson());
                        Person.BreakMenu();
                        break;
                    case "4":
                        Console.WriteLine(Person.SearchPerson());
                        Person.BreakMenu();
                        break;
                    case "5":
                        exitb = true;
                        break;
                    default:
                        Console.WriteLine("Нет такого варианта");
                        Person.BreakMenu();
                        break;
                }
            }
        }
        public class Person
        {
            public static string[] mas = new string[30];
            public static string[] surname = new string[30]; //фамилия
            public static string[] name = new string[30]; //имя
            public static string[] patronymic = new string[30]; //отчество
            public static string[] post = new string[30]; //должность
            public static int j = 0;
            public static void BreakMenu()
            {
                Console.Write("Для продолжения нажмите любую клавишу...");
                Console.ReadKey();
                Console.Clear();
            }
            public static string AddPerson()
            {
                Console.Write("Введите фамилию: ");
                surname[j] = Console.ReadLine();
                Console.Write("Введите имя: ");
                name[j] = Console.ReadLine();
                Console.Write("Введите отчество: ");
                patronymic[j] = Console.ReadLine();
                Console.Write("Введите должность: ");
                post[j] = Console.ReadLine();
                mas[j] = Convert.ToString(j+1) + ") " + surname[j] + " " + name[j] + " " + patronymic[j] + "\t - " + post[j];
                j++;
                return "Человек добавлен в базу";
            }
            public static string AllPerson()
            {
                if (j <= 0)
                {
                    return "Нет ни одного досье";
                }
                else
                {
                    Console.WriteLine("Полное досье:");
                    for (int i = 0; i <= j; i++)
                    {
                        Console.WriteLine(mas[i]);
                    }
                    return "Представлены все досье";
                }
            }
            public static string SearchPerson()
            {
                Console.Write("Введите фамилию: ");
                string surn = Console.ReadLine();
                for (int i = 0; i < surname.Length; i++)
                {
                    if (surn == surname[i])
                    {
                        Console.WriteLine(mas[i]);
                    }
                }
                return "Поиск выполнен";
            }
            public static string DeletePerson()
            {
                if (j <= 0)
                {
                    return "Нет ни одного досье";
                }
                else
                {
                    Console.Write("Введите номер человека, которого хотите удалить из базы: ");
                    j = Convert.ToInt32(Console.ReadLine());
                    mas[j - 1] = Convert.ToString(j) + ") Человек удален из базы";
                    return "Человек был удален из базы";
                }
            }
        }
       
    }
}