﻿using System;

namespace BKA_Task_03
{
    class Program
    {
        static void Main(string[] args)
        {
            string password = "13pass"; //секретный пароль
            string secret = "Задание сделано 14 марта"; //секретное письмо

            for(var i = 1; i < 4; i++)
            {
                Console.Write("Введите пароль: ");
                if (Console.ReadLine() == password)
                {
                    Console.Write("Секретное письмо: " + secret);
                    Console.ReadLine();
                    break;
                }
                else
                {
                    Console.WriteLine("Пароль неверный, " + i + "/3 попытка");
                }
            }
            
        }
    }
}
