﻿using System;

namespace BKA_Task_04
{
    class Program
    {
        static void Main(string[] args)
        {
            bool gameEnd = false;
            Random rand = new Random();
            int bossHealth = rand.Next(300, 500); //здоровье босса
            int gamerHealth = rand.Next(300, 600); //здоровье игрока
            int spells; //номер заклинания
            int i = 1; //раунд
            bool kyst = false; //для пропуска удара от босса, когда игрок в кустах
            bool spells3 = false;

            Console.WriteLine("Игра - победи босса\n" +
                "Список заклинаний:\n" +
                "1) Fireball, наносит от 50 урона\n" +
                "2) Блинчики для подкрепления, добавляют от 40 до 90 здоровья\n" +
                "3) Спрятаться в кустах и переседеть этот ход, +20 к здоровью игрока\n" +
                "4) Усиление силы на 30 единиц и удар по боссу, -40 к здоровью игрока (можно воспользоваться только сразу после заклинания №3)\n" +
                "5) Послушать музыку, +30 к здоровью босса и +50 к здоровью игрока\n" +
                "\nУсловия:\n" +
                "Здоровье босса: {0}\n" +
                "Здоровье игрока: {1}\n", bossHealth, gamerHealth);

            while (gameEnd == false) //для выхода из игры
            {
                if (bossHealth <= 0)
                {
                    Console.WriteLine("Босс умер. ВЫ ПОБЕДИЛИ!!!");
                    Console.ReadKey();
                    gameEnd = true;
                }
                else if (gamerHealth <= 0)
                {
                    Console.WriteLine("Вы умерли :(");
                    Console.ReadKey();
                    gameEnd = true;
                }
                else
                {
                    int bossDamage = rand.Next(60, 100); //урон босса
                    int gamerDamage = rand.Next(50, 90); //урон игрока
                    int gamerMed = rand.Next(60, 90); //лечение игрока
                    Console.Write("Раунд №{0}\n" + "Ход игрока\n" + "Выберите номер заклинания(1-5): ", i);
                    spells = Convert.ToInt32(Console.ReadLine());
                    switch(spells)
                    {
                        case 1:
                            Console.WriteLine("Сила удара: {0}", gamerDamage);
                            bossHealth -= gamerDamage;
                            if (gamerHealth <= 0)
                            {
                                gamerHealth = 0;
                            }
                            else if (bossHealth < 0)
                            {
                                bossHealth = 0;
                            }
                            Console.WriteLine("Осталось здоровья у босса: {0}\n" + "Осталось здоровья у игрока: {1}\n", bossHealth, gamerHealth);
                            break;
                        case 2:
                            Console.WriteLine("Подкрепились, получили {0} здоровья", gamerMed);
                            gamerHealth += gamerMed;
                            Console.WriteLine("Осталось здоровья у босса: {0}\n" + "Осталось здоровья у игрока: {1}\n", bossHealth, gamerHealth);
                            break;
                        case 3:
                            Console.WriteLine("Спрятались в кустах");
                            kyst = true;
                            spells3 = true;
                            gamerHealth += 20;
                            Console.WriteLine("Осталось здоровья у босса: {0}\n" + "Осталось здоровья у игрока: {1}\n", bossHealth, gamerHealth);
                            break;
                        case 4:
                            if (spells3 == true)
                            {
                                Console.WriteLine("Сила удара: {0} + 30", gamerDamage);
                                gamerDamage += 30;
                                bossHealth -= gamerDamage;
                                gamerHealth -= 40;
                                Console.WriteLine("Осталось здоровья у босса: {0}\n" + "Осталось здоровья у игрока: {1}\n", bossHealth, gamerHealth);
                                gamerDamage -= 30;
                            }
                            else
                            {
                                Console.WriteLine("Вы не смогли воспользоваться этим заклинанием\n");
                            }
                            spells3 = false;
                            break;
                        case 5:
                            Console.WriteLine("Rest time тутуру");
                            Console.WriteLine("Отдохнули, босс +30 здоровья, игрок +50 здоровья");
                            bossHealth +=30;
                            gamerHealth += 50;
                            Console.WriteLine("Осталось здоровья у босса: {0}\n" + "Осталось здоровья у игрока: {1}\n", bossHealth, gamerHealth);
                            break;
                        default:
                            Console.WriteLine("Написано же с 1го по 5ое!!! Стук по лбу! -30 к здоровью игрока");
                            gamerHealth -= 30;
                            Console.WriteLine("Осталось здоровья у босса: {0}\n" + "Осталось здоровья у игрока: {1}\n", bossHealth, gamerHealth);
                            break;
                    }
                    if (gamerHealth > 0 && bossHealth > 0 && kyst == false)
                    {
                        i++;
                        Console.Write("Раунд №{0}\n" + "Ход босса\n", i);
                        Console.WriteLine("Сила удара: {0}", bossDamage);
                        gamerHealth -= bossDamage;
                        if (gamerHealth <= 0)
                        {
                            gamerHealth = 0;

                        }
                        else if (bossHealth < 0)
                        {
                            bossHealth = 0;
                        }
                            Console.WriteLine("Осталось здоровья у босса: {0}\n" + "Осталось здоровья у игрока: {1}\n", bossHealth, gamerHealth);
                        i++;
                    }
                    else if (gamerHealth > 0 && bossHealth > 0 && kyst == true)
                    {
                        i++;
                        Console.Write("Раунд №{0}\n" + "Ход босса\n", i);
                        Console.WriteLine("Босс не нашёл игрока...\n");
                        kyst = false;
                        i++;
                    }
                }
            }
        }
    }
}
