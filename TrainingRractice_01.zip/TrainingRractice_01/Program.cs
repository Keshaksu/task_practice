﻿using System;

namespace BKA_Task_01
{
    class Program
    {
        static void Main(string[] args)
        {
            int gold; //сколько золота изначально (уже переведено в int)
            string gold2; //сколько золота изначально
            int gold3; //сколько осталось после покупки
            int price; //цена кристалла
            int num; //сколько кристаллов покупает
            int num2; //подсчет хватит ли золота на кол-во введенных кристаллов
            bool check = false; //для выхода из цикла

            while (check == false)
            {
                Console.Write("Введите количество золота, которое вы имеете: ");
                gold2 = Console.ReadLine();

                try 
                {
                    gold = Convert.ToInt32 (gold2);
                    price = 10;
                    Console.Write("Стоимость одного кристалла: 10 золота. Сколько кристаллов желаете приобрести? ");
                    num = Convert.ToInt32(Console.ReadLine());
                    num2 = gold / (price * num); //хватит золота или нет

                    switch (num2)
                    {
                        case 0:
                            Console.WriteLine("Вам не хватает денег. У Вас есть {0} золота. Стоимость за {1} кристалла(ов) {2} золота", gold, num, price * num);
                            break;

                        default:
                            gold3 = gold - price * num; 
                            Console.WriteLine("У Вас есть " + num + " кристалла(ов) и осталось " + gold3 + " золота");
                            break;
                    }
                    Console.ReadKey();
                    check = true;
                }
                catch (FormatException) 
                {
                    Console.WriteLine("Некорректно введено число");
                }
            }
        }
    }
}
